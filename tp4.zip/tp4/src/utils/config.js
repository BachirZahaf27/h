export default {
    jwtsecret: "adir1g22oi8jd6fger411lguh84sduqp848iur"
}